package com.example.helthTracking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelthTrackingApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelthTrackingApplication.class, args);
	}

}
