package com.example.helthTracking.medications;

public enum MedicationForm {
    CAPSULE,
    TABLET,
    LIQUID
}
