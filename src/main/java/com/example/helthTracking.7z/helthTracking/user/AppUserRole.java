package com.example.helthTracking.user;

public enum AppUserRole {

    DOCTOR,
    PATIENT
}
